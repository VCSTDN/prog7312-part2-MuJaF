﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace PART1
{
    public partial class IdentifyingAreas : Window
    {
        private Dictionary<string, string> matches;
        private List<string> callNumbers;
        private List<string> descriptions;
        private List<Question> shuffledItems; // Store shuffled call numbers and descriptions
        private int currentIndex;
        private int wrongAttempts;

        public IdentifyingAreas()
        {
            InitializeComponent();

            // Initialize the matches dictionary
            matches = new Dictionary<string, string>();
            matches.Add("QA7.73", "Programming in C#");
            matches.Add("P56.95", "The Art of Computer Programming");
            matches.Add("R45.67", "Advanced Calculus");
            matches.Add("Q78.45", "Physics for Engineers");
            matches.Add("D45.78", "Organic Chemistry");
            matches.Add("E68.90", "Geology and Earth Sciences");
            matches.Add("F23.45", "Biology of Cells");
            matches.Add("G89.12", "Astronomy and Cosmology");
            matches.Add("H56.78", "Psychology and Human Behavior");
            matches.Add("I78.90", "Computer Information Systems");
            matches.Add("J23.45", "History of Art");
            matches.Add("K89.12", "Literature and Creative Writing");
            matches.Add("L56.78", "Economics Principles");
            matches.Add("M78.90", "Music Theory and Composition");
            matches.Add("N23.45", "Theater and Performing Arts");
            matches.Add("O89.12", "Sociology and Society");
            matches.Add("P56.78", "Religious Studies");
            matches.Add("U78.90", "French Language and Culture");

            // Initialize the call numbers and descriptions lists
            callNumbers = new List<string>(matches.Keys);
            descriptions = new List<string>(matches.Values);

            // Shuffle the order of the call numbers and descriptions
            Shuffle(callNumbers);
            Shuffle(descriptions);

            // Create a list of shuffled items for the top ListView
            shuffledItems = new List<Question>();
            for (int i = 0; i < callNumbers.Count; i++)
            {
                shuffledItems.Add(new Question { CallNumber = callNumbers[i], Description = descriptions[i] });
            }
            shuffledListView.ItemsSource = shuffledItems; // Populate the top ListView

            // Set the currentIndex and wrongAttempts to 0
            currentIndex = 0;
            wrongAttempts = 0;

            // Display the first description and ask for a call number
            DisplayCurrentMatch();
        }

        private void DisplayCurrentMatch()
        {
            if (currentIndex < descriptions.Count)
            {
                string currentDescription = descriptions[currentIndex];

                // Display the current description
                descriptionDisplay.Text = currentDescription;

                // Clear the input box
                callNumberInput.Text = "";

                // Enable input and check button
                callNumberInput.IsEnabled = true;
                checkButton.IsEnabled = true;
            }
            else
            {
                // The user has completed the game
                DisplayFinalResults();
            }
        }

        private void DisplayFinalResults()
        {
            // Show the user all the correct call numbers and descriptions
            List<Question> correctMatches = matches.Select(kv => new Question { CallNumber = kv.Key, Description = kv.Value }).ToList();
            itemListView.ItemsSource = correctMatches;

            // Calculate and show the score
            int totalMatches = matches.Count;
            int correctMatchesCount = currentIndex;
            int score = (correctMatchesCount * 100) / totalMatches;
            MessageBox.Show($"Congratulations! You've matched {correctMatchesCount} out of {totalMatches} correctly. Your score is: {score}%");

            // Disable the input box and check button
            callNumberInput.IsEnabled = false;
            checkButton.IsEnabled = false;
        }

        private void CheckButton_Click(object sender, RoutedEventArgs e)
        {
            if (currentIndex < descriptions.Count)
            {
                string currentCallNumber = callNumbers[currentIndex];
                string enteredCallNumber = callNumberInput.Text.Trim();

                if (string.Equals(currentCallNumber, enteredCallNumber, StringComparison.OrdinalIgnoreCase))
                {
                    // Correct match
                    MessageBox.Show("Correct!");
                    currentIndex++;
                    wrongAttempts = 0;

                    if (currentIndex < descriptions.Count)
                    {
                        // Display the next description and ask for a call number
                        DisplayCurrentMatch();
                    }
                    else
                    {
                        // End of the game
                        DisplayFinalResults();
                    }
                }
                else
                {
                    // Incorrect match
                    MessageBox.Show("Sorry, please try again.");
                    wrongAttempts++;

                    if (wrongAttempts >= 4)
                    {
                        // The user exceeded the maximum wrong attempts
                        MessageBox.Show("You've exceeded the maximum wrong attempts. The game is over.");
                        DisplayFinalResults();
                    }
                }
            }
        }

        private void BackButton_Click(object sender, RoutedEventArgs e)
        {
            // Close the current window and return to the main window
            MainWindow mainWindow = new MainWindow();
            this.Close();
            mainWindow.Show();
            
        }


        private void Shuffle<T>(List<T> list)
        {
            Random rng = new Random();
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}
