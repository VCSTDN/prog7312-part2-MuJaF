﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;

namespace PART1
{
    public partial class MainWindow : Window
    {
        private List<string> generatedCallNumbers = new List<string>();
        private List<string> userEnteredCallNumbers = new List<string>();
        
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnIdentifyAreas_Click(object sender, RoutedEventArgs e)
        {
            IdentifyingAreas newWindow = new IdentifyingAreas();
            // Hide the existing window
            this.Hide();
            // Show the new window
            newWindow.Show();

        }

 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
 ///////////////////////////////////////////////THE REPLACE BOOKS CODE IS BELOW HERE///////////////////////////////////////////////////////////////////////
 //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            private void btnReplaceBooks_Click(object sender, RoutedEventArgs e)
        {
            // Disable and enable appropriate buttons
            btnReplaceBooks.IsEnabled = false;
            btnIdentifyAreas.IsEnabled = false;
            btnFindCallNumbers.IsEnabled = false;
            first.Visibility = Visibility.Collapsed;
            pnlReorder.Visibility = Visibility.Visible;

            // Clear previous results
            txtResult.Text = "";

            // Clear the TextBox for user input
            txtUserInput.Text = "";
            userEnteredCallNumbers.Clear();

            // Generate and display random call numbers
            generatedCallNumbers = GenerateCallNumbers(10);
            callNumberListBox.ItemsSource = generatedCallNumbers; // Set the ItemsSource

            // Focus on the TextBox for user input
            txtUserInput.Focus();
        }

        private List<string> GenerateCallNumbers(int count)
        {
            List<string> callNumbers = new List<string>();
            Random random = new Random();

            for (int i = 0; i < count; i++)
            {
                // Generate a random Dewey Decimal topic (between 0 and 999)
                double deweyTopic = random.NextDouble() * 1000;

                // Format the Dewey Decimal topic with two decimal places
                string formattedDeweyTopic = deweyTopic.ToString("0.00");

                // Generate a random author name (three random letters)
                string author = new string(Enumerable.Repeat("ABCDEFGHIJKLMNOPQRSTUVWXYZ", 3)
                    .Select(s => s[random.Next(s.Length)]).ToArray());

                // Combine the formatted Dewey Decimal topic and author to create a call number
                string callNumber = $"{formattedDeweyTopic} {author}";

                callNumbers.Add(callNumber);
            }

            return callNumbers;
        }


        private void btnSubmitInput_Click(object sender, RoutedEventArgs e)
        {
            string[] enteredNumbers = txtUserInput.Text.Split(new[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
            userEnteredCallNumbers = enteredNumbers.ToList();

            // Check if the call numbers are in ascending order
            bool isCorrectOrder = CheckOrder(userEnteredCallNumbers);

            if (isCorrectOrder)
            {
                txtResult.Text = "Congratulations! You got the ordering right. +10 points";
            }
            else
            {
                txtResult.Text = "Oops! The ordering is incorrect. Try again. -5 points";
            }
        }

        private bool CheckOrder(List<string> callNumbers)
        {
            if (callNumbers.Count == generatedCallNumbers.Count)
            {
                for (int i = 0; i < callNumbers.Count - 1; i++)
                {
                    if (string.Compare(callNumbers[i], callNumbers[i + 1]) > 0)
                    {
                        return false;
                    }
                }
                return true;
            }
            return false;
        }

        private void back_Click(object sender, RoutedEventArgs e)
        {
            // Show the main menu and hide the reorder UI
            pnlReorder.Visibility = Visibility.Collapsed;
            first.Visibility = Visibility.Visible;
            btnReplaceBooks.IsEnabled = true;
            btnIdentifyAreas.IsEnabled = true;
            btnFindCallNumbers.IsEnabled = false;
        }
        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////




    }
}
