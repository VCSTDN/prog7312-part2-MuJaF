*  CONTENTS OF THIS DOCUMENT
************************************************************

This document contains the following sections:

1.  Overview
2.  System Requirements
3.  Installing the Software

************************************************************
* 1.  OVERVIEW
************************************************************
This program requires the user to view call numbers and enter
them in ascending order. Reward will be given for getting the
order correct.
Other features will be implmented in part 2 and 3 of this POE.
************************************************************
* 2.  SYSTEM REQUIREMENTS
************************************************************

1.  The system can be run on the following
    operating system:
    
    - LENOVO_MT_81W8_BU_idea_FM_IdeaPad S145-15IIL


2.  The system should contain at least the minimum system 
    memory required by the operating system.

4. The following additional software is required 
 
	Microsoft Visual Studio Community 2022

************************************************************
* 3.  INSTALLING THE SOFTWARE
************************************************************

1. Unzipp the [_ST10091229_PROG7312_PART2]
    Right click on folder and then select extract all

2. Open File on Visual Studio
     - Select [PART1]
     - Select [PART1.sln]

3. Run the code 
